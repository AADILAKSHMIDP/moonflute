MOON FLUTE — by Mochi Muffin

Free static website for GitHub Pages.

1. Create a public repository named YOURUSERNAME.github.io.
2. Upload index.html.
3. In Settings → Pages, choose Deploy from branch → main → / (root).
4. Open https://YOURUSERNAME.github.io

Before launch, replace the Google Forms button URL in index.html with your real order form, Instagram, or WhatsApp link.
